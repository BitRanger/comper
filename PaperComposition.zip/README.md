comper
======
***Comper*** 
Automatic Test Paper Composition Using Genetic Algorithm

based on Awake, Gplume-context, MySQL and SWT
