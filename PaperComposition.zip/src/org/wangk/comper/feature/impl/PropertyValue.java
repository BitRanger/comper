package org.wangk.comper.feature.impl;

/**
 * 用于注入属性
 * @author BowenCai
 *
 */
public class PropertyValue {

}
