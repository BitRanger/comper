package org.wangk.comper.feature.builder;

import org.wangk.comper.feature.impl.PropertyValue;

public class HtmlBuilder extends PropertyValue {

	
}
